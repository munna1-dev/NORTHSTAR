import pg from 'pg'
import fs from 'node:fs/promises'

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  max: 1,
  connectionTimeoutMillis: 15000,
})

let client

try {
  const url = new URL(process.env.DATABASE_URL)
  const ref = decodeURIComponent(url.username).split('.').at(-1)

  if (
    url.hostname !== 'aws-1-us-west-2.pooler.supabase.com' ||
    ref !== 'pnwtqhbbtosymbtdifkk'
  ) {
    throw new Error('Production project verification failed.')
  }

  client = await pool.connect()
  console.log('Production database verified.')

  await client.query('BEGIN')

  const existing = await client.query(
    'SELECT version FROM schema_migrations WHERE version = $1',
    ['024']
  )

  if (existing.rowCount) {
    await client.query('ROLLBACK')
    console.log('Migration 024 already recorded; no changes needed.')
  } else {
    const sql = await fs.readFile(
      'database/024_kyc_workflow.sql',
      'utf8'
    )

    await client.query(sql)

    await client.query(
      'INSERT INTO schema_migrations (version) VALUES ($1)',
      ['024']
    )

    await client.query('COMMIT')
    console.log('Migration 024 applied and recorded.')
  }

  const check = await client.query(`
    SELECT
      EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'public'
          AND table_name = 'kyc_documents'
          AND column_name = 'reviewed_by_staff_id'
      ) AS reviewer_column,
      EXISTS (
        SELECT 1 FROM management_permissions
        WHERE permission_key = 'kyc.view'
      ) AS view_permission,
      EXISTS (
        SELECT 1 FROM management_permissions
        WHERE permission_key = 'kyc.review'
      ) AS review_permission,
      EXISTS (
        SELECT 1 FROM schema_migrations
        WHERE version = '024'
      ) AS migration_recorded
  `)

  console.log('VERIFICATION:', check.rows[0])

  if (Object.values(check.rows[0]).some(v => v !== true)) {
    throw new Error('Post-migration verification failed.')
  }

  console.log('KYC MIGRATION 024: SUCCESS')
} catch (error) {
  if (client) {
    try { await client.query('ROLLBACK') } catch {}
  }
  console.error('MIGRATION FAILED:', error.message)
  process.exitCode = 1
} finally {
  client?.release()
  await pool.end()
}
