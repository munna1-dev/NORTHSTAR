import type { VercelRequest } from '@vercel/node'
import { getStaffFromSession } from './staff-session.js'
import { getDb } from '../db/client.js'

export type ManagementPermission =
  | 'customers.view'
  | 'customers.review'
  | 'customers.approve'
  | 'customers.suspend'
  | 'customers.block'
  | 'customers.reactivate'
  | 'customers.close'
  | 'staff.view'
  | 'staff.approve'
  | 'staff.reject'
  | 'staff.suspend'
  | 'staff.block'
  | 'staff.reactivate'
  | 'staff.terminate'
  | 'staff.roles'
  | 'staff.permissions'
  | 'applications.view'
  | 'applications.approve'
  | 'applications.reject'
  | 'applications.kyc'
  | 'kyc.view'
  | 'kyc.review'
  | 'accounts.view'
  | 'accounts.activate'
  | 'accounts.freeze'
  | 'accounts.close'
  | 'transactions.view'
  | 'transfers.view'
  | 'transfers.approve'
  | 'transfers.reject'
  | 'deposits.view'
  | 'deposits.approve'
  | 'deposits.reject'
  | 'withdrawals.view'
  | 'withdrawals.approve'
  | 'withdrawals.reject'
  | 'payments.view'
  | 'payments.approve'
  | 'payments.reject'
  | 'cards.view'
  | 'cards.manage'
  | 'support.view'
  | 'support.manage'
  | 'reports.view'
  | 'audit.view'
  | 'security.view'
  | 'system.settings'
  | 'dashboard.view'
  | 'profile.view'
  | 'profile.update'

export interface ManagementUser {
  id: string
  customer_number: string
  first_name: string
  last_name: string
  email: string
  phone: string | null
  status: string
  role: string
  two_factor_enabled: boolean
  staff_status: string | null
  staff_id: string | null
  department: string | null
}

export async function getManagementUser(
  request: VercelRequest,
): Promise<ManagementUser | null> {
  const staff = await getStaffFromSession(request)

  if (!staff) {
    return null
  }

  const db = getDb()

  const result = await db.query(
    `
      SELECT
        s.id,
        s.staff_number AS customer_number,
        s.first_name,
        s.last_name,
        s.email,
        s.phone,
        s.status,
        COALESCE(
          (
            SELECT r.role_key
            FROM staff_role_assignments_v2 sra
            JOIN management_roles r
              ON r.id = sra.role_id
            WHERE sra.staff_id = s.id
              AND r.is_active = TRUE
            ORDER BY sra.assigned_at DESC
            LIMIT 1
          ),
          'staff'
        ) AS role,
        s.two_factor_enabled,
        s.status AS staff_status,
        s.id AS staff_id,
        s.department
      FROM staff s
      WHERE s.id = $1
        AND s.status = 'active'
      LIMIT 1
    `,
    [staff.id],
  )

  if (result.rowCount !== 1) {
    return null
  }

  return result.rows[0] as ManagementUser
}

export async function requireManagement(
  request: VercelRequest,
): Promise<ManagementUser | null> {
  return getManagementUser(request)
}

export async function hasManagementPermission(
  user: ManagementUser,
  permission: ManagementPermission,
): Promise<boolean> {
  if (user.role === 'super_manager') {
    return true
  }

  const db = getDb()

  const result = await db.query(
    `
      WITH role_permissions AS (
        SELECT DISTINCT p.permission_key
        FROM staff_role_assignments_v2 sra
        JOIN management_roles r
          ON r.id = sra.role_id
        JOIN management_role_permissions rp
          ON rp.role_id = r.id
        JOIN management_permissions p
          ON p.id = rp.permission_id
        WHERE sra.staff_id = $1
          AND r.is_active = TRUE
      ),
      overrides AS (
        SELECT
          p.permission_key,
          spa.effect
        FROM staff_permission_assignments_v2 spa
        JOIN management_permissions p
          ON p.id = spa.permission_id
        WHERE spa.staff_id = $1
      )
      SELECT 1
      WHERE NOT EXISTS (
        SELECT 1
        FROM overrides
        WHERE permission_key = $2
          AND effect = 'deny'
      )
      AND (
        EXISTS (
          SELECT 1
          FROM overrides
          WHERE permission_key = $2
            AND effect = 'allow'
        )
        OR EXISTS (
          SELECT 1
          FROM role_permissions
          WHERE permission_key = $2
        )
      )
      LIMIT 1
    `,
    [user.id, permission],
  )

  return result.rowCount === 1
}

export async function getEffectiveManagementPermissions(
  user: ManagementUser,
): Promise<string[]> {
  if (user.role === 'super_manager') {
    const db = getDb()

    const result = await db.query(
      `
        SELECT permission_key
        FROM management_permissions
        ORDER BY permission_key
      `,
    )

    return result.rows.map(
      (row: { permission_key: string }) => row.permission_key,
    )
  }

  const db = getDb()

  const result = await db.query(
    `
      WITH role_permissions AS (
        SELECT DISTINCT p.permission_key
        FROM staff_role_assignments_v2 sra
        JOIN management_roles r
          ON r.id = sra.role_id
        JOIN management_role_permissions rp
          ON rp.role_id = r.id
        JOIN management_permissions p
          ON p.id = rp.permission_id
        WHERE sra.staff_id = $1
          AND r.is_active = TRUE
      ),
      overrides AS (
        SELECT
          p.permission_key,
          spa.effect
        FROM staff_permission_assignments_v2 spa
        JOIN management_permissions p
          ON p.id = spa.permission_id
        WHERE spa.staff_id = $1
      )
      SELECT p.permission_key
      FROM management_permissions p
      WHERE
        (
          EXISTS (
            SELECT 1
            FROM role_permissions rp
            WHERE rp.permission_key = p.permission_key
          )
          OR EXISTS (
            SELECT 1
            FROM overrides o
            WHERE o.permission_key = p.permission_key
              AND o.effect = 'allow'
          )
        )
        AND NOT EXISTS (
          SELECT 1
          FROM overrides o
          WHERE o.permission_key = p.permission_key
            AND o.effect = 'deny'
        )
      ORDER BY p.permission_key
    `,
    [user.id],
  )

  return result.rows.map(
    (row: { permission_key: string }) => row.permission_key,
  )
}

export async function requirePermission(
  request: VercelRequest,
  permission: ManagementPermission,
): Promise<ManagementUser | null> {
  const user = await getManagementUser(request)

  if (!user) {
    return null
  }

  if (await hasManagementPermission(user, permission)) {
    return user
  }

  return null
}

export async function requireAnyPermission(
  request: VercelRequest,
  permissions: readonly ManagementPermission[],
): Promise<ManagementUser | null> {
  const user = await getManagementUser(request)

  if (!user) {
    return null
  }

  if (user.role === 'super_manager') {
    return user
  }

  for (const permission of permissions) {
    if (await hasManagementPermission(user, permission)) {
      return user
    }
  }

  return null
}

export function managementResponse(user: ManagementUser) {
  return {
    id: user.id,
    customerNumber: user.customer_number,
    firstName: user.first_name,
    lastName: user.last_name,
    email: user.email,
    phone: user.phone,
    status: user.status,
    role: user.role,
    twoFactorEnabled: user.two_factor_enabled,
    staffStatus: user.staff_status,
    staffId: user.staff_id,
    department: user.department,
  }
}
