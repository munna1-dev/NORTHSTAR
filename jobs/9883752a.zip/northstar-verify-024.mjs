import pg from 'pg'

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
  max: 1,
})

try {
  const roles = await pool.query(`
    SELECT r.role_key, p.permission_key
    FROM management_role_permissions rp
    JOIN management_roles r ON r.id = rp.role_id
    JOIN management_permissions p ON p.id = rp.permission_id
    WHERE r.role_key IN ('super_manager', 'kyc_compliance')
      AND p.permission_key IN ('kyc.view', 'kyc.review')
    ORDER BY r.role_key, p.permission_key
  `)

  const foreignKey = await pool.query(`
    SELECT
      tc.constraint_name,
      ccu.table_name AS referenced_table,
      ccu.column_name AS referenced_column
    FROM information_schema.table_constraints tc
    JOIN information_schema.key_column_usage kcu
      ON tc.constraint_name = kcu.constraint_name
     AND tc.constraint_schema = kcu.constraint_schema
    JOIN information_schema.constraint_column_usage ccu
      ON ccu.constraint_name = tc.constraint_name
     AND ccu.constraint_schema = tc.constraint_schema
    WHERE tc.table_schema = 'public'
      AND tc.table_name = 'kyc_documents'
      AND tc.constraint_type = 'FOREIGN KEY'
      AND kcu.column_name = 'reviewed_by_staff_id'
  `)

  console.log('KYC ROLE PERMISSIONS:')
  console.table(roles.rows)

  console.log('REVIEWER FOREIGN KEY:')
  console.table(foreignKey.rows)

  console.log(
    roles.rowCount === 4 &&
    foreignKey.rows.some(
      row => row.referenced_table === 'staff' &&
             row.referenced_column === 'id'
    )
      ? 'PRODUCTION VERIFICATION: SUCCESS'
      : 'VERIFICATION NEEDS REVIEW'
  )
} catch (error) {
  console.error('VERIFICATION FAILED:', error.message)
  process.exitCode = 1
} finally {
  await pool.end()
}
